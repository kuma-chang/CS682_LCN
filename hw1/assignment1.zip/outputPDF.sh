jupyter nbconvert --to pdf features.ipynb
jupyter nbconvert --to pdf knn.ipynb
jupyter nbconvert --to pdf softmax.ipynb
jupyter nbconvert --to pdf svm.ipynb
jupyter nbconvert --to pdf two_layer_net.ipynb
jupyter nbconvert --to pdf cool_bonus.ipynb
